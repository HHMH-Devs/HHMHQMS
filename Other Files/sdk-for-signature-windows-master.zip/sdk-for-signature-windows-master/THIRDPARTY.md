# Third Party Software and Licenses

Below are terms, notices and disclaimers for third party software not part of the SDK but included in the sample code.

* No third party libraries used
