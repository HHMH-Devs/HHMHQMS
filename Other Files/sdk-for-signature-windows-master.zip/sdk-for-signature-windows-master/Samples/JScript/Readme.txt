Running the javascript tests

Install the Wacom Signature SDK

Start a dos prompt
C:\test\jscriptt>

Run a 32bit test on Win7-32 or Win7-64:
C:\Test\jscript>Run-JS.bat CaptureImage.js

Run a 64bit test on Win7-64:
C:\Test\jscript>Run-JS.x64.bat CaptureImage.js
