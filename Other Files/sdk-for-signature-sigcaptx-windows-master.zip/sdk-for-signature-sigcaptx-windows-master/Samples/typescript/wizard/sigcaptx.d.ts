/***************************************************************************
  sigcaptx.ts
   
  This is the main control file for starting up the wizard sample
  
  Copyright (c) 2021 Wacom Co. Ltd. All rights reserved.
  
   v1.0
  
***************************************************************************/
import { HTMLIds } from './SigCaptX-Globals';
export declare const HTMLTags: HTMLIds;
