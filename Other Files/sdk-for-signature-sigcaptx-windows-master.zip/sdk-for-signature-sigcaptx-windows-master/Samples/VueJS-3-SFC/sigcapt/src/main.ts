import { createApp } from 'vue';
import App from './App.vue';

export const vueapp = createApp(App).mount('#app');
