<template>
  <sig-capt/>
</template>

<script>
import SigCapt from '@/components/SigCapt.vue';

export default
{
  components:
  {
    SigCapt
  }
};

</script>
