<template>
  <page-header/>
  <wiz-pin-main/>
</template>

<script>
import PageHeader from '@/components/PageHeader.vue';
import WizPinMain from '@/components/WizPinMain.vue';

export default
{
  components:
  {
    PageHeader,
    WizPinMain
  }
};
</script>
