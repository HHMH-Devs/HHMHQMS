<template>
  <header>
    <h2>SigCaptX Vue JS Wizard PIN Script Sample</h2>
  </header>
</template>
