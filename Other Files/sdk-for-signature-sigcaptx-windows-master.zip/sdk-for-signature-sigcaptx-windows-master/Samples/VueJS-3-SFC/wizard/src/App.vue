<template>
  <page-header/>
  <wizard-main/>
</template>

<script>
import PageHeader from '@/components/PageHeader.vue';
import WizardMain from '@/components/WizardMain.vue';

export default
{
  components:
  {
    PageHeader,
    WizardMain
  }
};
</script>
