<template>
  <header>
    <h2>SigCaptX Vue JS Wizard Script Sample</h2>
  </header>
</template>
