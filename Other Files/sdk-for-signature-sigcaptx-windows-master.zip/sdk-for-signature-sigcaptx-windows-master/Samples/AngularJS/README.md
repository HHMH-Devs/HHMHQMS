# Angular Sample for SigCaptX for Windows

## Download the SDK

The Signature SDK and SigCaptX library will need to be installed on your local (client) machine.  
Please see the GETTING-STARTED document in the home folder for instructions on installing the Signature SDK and SigCaptX library and licence.

The sample demonstrates signature capture with options to save the signature as a SigText value and restore it.





