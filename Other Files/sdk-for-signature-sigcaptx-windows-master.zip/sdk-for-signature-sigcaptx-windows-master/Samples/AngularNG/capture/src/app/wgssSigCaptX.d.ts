    export class WacomGSS_SignatureSDK
    {
        constructor(_onDetectRunning, serviceport);
    }
    export const JSONreq;