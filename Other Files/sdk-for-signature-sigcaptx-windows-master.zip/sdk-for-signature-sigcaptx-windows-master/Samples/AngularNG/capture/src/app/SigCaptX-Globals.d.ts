export declare var wgssSignatureSDK: any;
export declare var sigObj: any;
export declare var imageBox: any;
export declare var sigsdkptr: any;
export declare var scriptIsRunning: boolean;
export declare var timeout: any;
export declare const BITMAP_BACKGROUNDCOLOR = 16777215;
export declare const BITMAP_IMAGEFORMAT = "bmp";
export declare const BITMAP_INKCOLOR = 0;
export declare const BITMAP_INKWIDTH = 0.7;
export declare const BITMAP_PADDING_X = 4;
export declare const BITMAP_PADDING_Y = 4;
export declare const TIMEOUT = 1500;
export declare const SERVICEPORT = 10500;
export declare const LICENCEKEY = "eyJhbGciOiJSUzUxMiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiI3YmM5Y2IxYWIxMGE0NmUxODI2N2E5MTJkYTA2ZTI3NiIsImV4cCI6MjE0NzQ4MzY0NywiaWF0IjoxNTYwOTUwMjcyLCJyaWdodHMiOlsiU0lHX1NES19DT1JFIiwiU0lHQ0FQVFhfQUNDRVNTIl0sImRldmljZXMiOlsiV0FDT01fQU5ZIl0sInR5cGUiOiJwcm9kIiwibGljX25hbWUiOiJTaWduYXR1cmUgU0RLIiwid2Fjb21faWQiOiI3YmM5Y2IxYWIxMGE0NmUxODI2N2E5MTJkYTA2ZTI3NiIsImxpY191aWQiOiJiODUyM2ViYi0xOGI3LTQ3OGEtYTlkZS04NDlmZTIyNmIwMDIiLCJhcHBzX3dpbmRvd3MiOltdLCJhcHBzX2lvcyI6W10sImFwcHNfYW5kcm9pZCI6W10sIm1hY2hpbmVfaWRzIjpbXX0.ONy3iYQ7lC6rQhou7rz4iJT_OJ20087gWz7GtCgYX3uNtKjmnEaNuP3QkjgxOK_vgOrTdwzD-nm-ysiTDs2GcPlOdUPErSp_bcX8kFBZVmGLyJtmeInAW6HuSp2-57ngoGFivTH_l1kkQ1KMvzDKHJbRglsPpd4nVHhx9WkvqczXyogldygvl0LRidyPOsS5H2GYmaPiyIp9In6meqeNQ1n9zkxSHo7B11mp_WXJXl0k1pek7py8XYCedCNW5qnLi4UCNlfTd6Mk9qz31arsiWsesPeR9PN121LBJtiPi023yQU8mgb9piw_a-ccciviJuNsEuRDN3sGnqONG3dMSA";
export declare class HTMLIds {
    btnRestore: any;
    checkBoxUseB64: any;
    checkShowSigtext: any;
    firstName: any;
    imageBox: any;
    lastName: any;
    textSig: any;
    txtDisplay: any;
    constructor();
}
