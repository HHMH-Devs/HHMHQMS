﻿using System.Web.UI;

namespace ASP_Sample.Account
{
    public partial class ResetPasswordConfirmation : Page
    {
    }
}